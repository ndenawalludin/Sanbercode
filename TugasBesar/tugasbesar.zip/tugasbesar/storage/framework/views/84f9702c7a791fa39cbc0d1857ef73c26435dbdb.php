<?php $__env->startSection('content'); ?>
<div class="container">
    <form class="" action="<?php echo e(route ('category.store')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="">Baju</label>
            <input type="text" class="form-control" name="baju">
        </div>
        <div class="form-group">
            <label for="">Celana</label>
            <input type="text" class="form-control" name="celana">
        </div>
    
        <div class="form-group">
             <input type="submit" class="btn btn-primary" value="Save">
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>