<?php $__env->startSection('content'); ?>
    <div class="panel panel-dafault">
        <div class="panel-heading">Category</div>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel-body">
                    <div class="pull-right">
                        <form action="<?php echo e(route('category.destroy', $category)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-xs btn-danger">Hapus</button>
                        </form>
                    </div>

                    <div class="form-group">
                        <div class="panel-heading"><?php echo e($category->baju); ?></div>
                    </div>
                    <div class="form-group">
                        <div class="panel-heading"><?php echo e($category->celana); ?></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>