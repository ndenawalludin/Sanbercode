<!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='utf-8'>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>

<style>
    
    </style>
<!-- modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header bg-success">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Keranjang Belanja Anda !</h4>
        </div>
        <div class="modal-body">          
  <table class="table">
    <thead>
      <tr>
        <th>Ghebuk</th>
        <th>Harga </th>
        <th>Jumlah </th>
        <th>Optional</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Krepek</td>
        <td>12.000</td>
        <td>12</td>
        <td>
            <a href="#">
            <span class="glyphicon glyphicon-plus-sign"></span>
            </a>
            <a href="#">
            <span class="glyphicon glyphicon-minus-sign"></span>
            </a>
            <a href="#">
            <span class="glyphicon glyphicon-remove-sign"></span>
            </a>
        </td>
      </tr>
      <tr>
        <td>Kocor</td>
        <td>12.000</td>
        <td>12</td>
        <td>
            <a href="#">
            <span class="glyphicon glyphicon-plus-sign"></span>
            </a>
            <a href="#">
            <span class="glyphicon glyphicon-minus-sign"></span>
            </a>
            <a href="#">
            <span class="glyphicon glyphicon-remove-sign"></span>
            </a>
        </td>
      </tr>
      <tr>
         <td>Nang-nginang</td>
        <td>12.000</td>
        <td>12</td>
        <td>
            <a href="#">
            <span class="glyphicon glyphicon-plus-sign"></span>
            </a>
            <a href="#">
            <span class="glyphicon glyphicon-minus-sign"></span>
            </a>
            <a href="#">
            <span class="glyphicon glyphicon-remove-sign"></span>
            </a>
        </td>
      </tr>
      <tr>
         <th>Total</th>
        <th>36.000</th>
        <th>36</th>
        <td>
        </td>
      </tr>
    </tbody>
  </table>
        </div>
        <div class="modal-footer bg-success">
          <button type="button" class="btn btn-warning" data-dismiss="modal">Check Out</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
        </div>
      </div>
       
    </div>
  </div>

<body>
    @include('coba.navbar')
 
    <!-- CONTAINER -->
<div class="container">
 
 <!-- letakkan semua code disini -->
 
<!-- baris kedua -->
<div class="row">
        <div class="col-sm-8 col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading"><span class="glyphicon glyphicon-star-empty"></span> Our Produk !</div>
                <div class="panel-body">
                <!-- bootstrap carousel -->
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <!-- Carousel indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                        <li data-target="#myCarousel" data-slide-to="2"></li>
                    </ol>   
                    <!-- Wrapper for carousel items -->
                    <div class="carousel-inner">
                        <div class="item active">
                            <img src="images/m/a.jpg">
                            <div class="carousel-caption">
                              <h3>Ghebuk </h3>
                              <p>Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              </p>
                            </div>
                        </div>
                        <div class="item">
                            <img src="images/m/b.jpg">
                            <div class="carousel-caption">
                              <h3>Rap-Orap</h3>
                              <p>Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              </p>
                            </div>
                        </div>
                        <div class="item">
                            <img src="images/m/a.jpg">
                            <div class="carousel-caption">
                              <h3>Krepek Tette</h3>
                              <p>Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              Lorem ipsum dolor sit amet consectetur…
                              </p>
                            </div>
                        </div>
                    </div>
                    <!-- Carousel controls -->
                    <a class="carousel-control left" href="#myCarousel" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                    </a>
                    <a class="carousel-control right" href="#myCarousel" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                    </a>
                </div>
                <!-- end bootsrap carousel -->
                </div><!-- body panel pertama akhirnya -->
            </div>
        </div>
        <div class="col-sm-4 col-xs-12">
        <div class="panel panel-success">
                <div class="panel-heading"><span class="glyphicon glyphicon-shopping-cart"></span> Cart !</div>
                <div class="panel-body"> 
                    <table class="table">
                        <tr class="success">
                            <th>Barang </th>
                            <th>Jumlah </th>
                        </tr>
                        <tr>
                            <td>Krupuk</td>
                            <td><span class="badge badge-success">2</span></td>
                        </tr>
                        <tr>
                            <td>Nang-nginang</td>
                            <td><span class="badge badge-success">5</span></td>
                        </tr>
                        <tr>
                            <td>Ghebuk</td>
                            <td><span class="badge badge-success">3</span></td>
                        </tr>
                        <tr>  
                            <td class="success"></td>
                            <td class="success"><span class="label label-success">Rp. 10.000 </span></td>
                        </tr>
                    </table>
                    <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal"> View Cart </button>
                    <button type="button" class="btn btn-success btn-sm"  >Chek Out </button>
                </div>
            </div>
        </div>
    </div>
<!-- akhir baris kedua -->
  @include('coba.baris3')

  @include('coba.baris5')
 </div>
 <!-- AKHIR DARI CONTAINER -->
</body>
</html>