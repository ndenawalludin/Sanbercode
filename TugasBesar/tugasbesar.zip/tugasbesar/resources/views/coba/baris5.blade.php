<div class="row">
            <div class="col-sm-3 col-xs-6">
                <div class="panel panel-success">
                  <div class="panel-heading">
                    <h3 class="panel-title">About Us</h3>
                  </div>
                  <div class="panel-body">
                    <ul>
                        <li><span class="glyphicon glyphicon-th-large"></span> PT. Gherus </li>
                        <li><span class="glyphicon glyphicon-road"></span> Jl. jalan Gg.XXX </li>
                        <li><span class="glyphicon glyphicon-phone-alt"></span> 0819393939393 </li>
                        <li><span class="glyphicon glyphicon-share-alt"></span> fb/gherus </li>
                        <li><span class="glyphicon glyphicon-share-alt"></span> @Gherus </li>
                    </ul>
                  </div>
                </div>
            </div>
            <div class="col-sm-3 col-xs-6">
                <div class="panel panel-success">
                  <div class="panel-heading">
                    <h3 class="panel-title">Our Partner !</h3>
                  </div>
                  <div class="panel-body">
                    <ul>
                        <li><span class="glyphicon glyphicon-asterisk"></span> PT. Rap-Orap </li>
                        <li><span class="glyphicon glyphicon-qrcode"></span> PT. Ghebuk </li>
                        <li><span class="glyphicon glyphicon-refresh"></span> PT. Kocor </li>
                        <li><span class="glyphicon glyphicon-leaf"></span> PT. Krepek Tette </li>
                        <li><span class="glyphicon glyphicon-fire"></span> PT. Tapay </li>
                    </ul>
                  </div>
                </div>
            </div>
            <div class="col-sm-3 col-xs-6">
                <div class="panel panel-success">
                  <div class="panel-heading">
                    <h3 class="panel-title">Help Desk</h3>
                  </div>
                  <div class="panel-body">
                    <ul> 
                        <li><span class="glyphicon glyphicon-comment"></span> Need help ? </li>
                        <li><span class="glyphicon glyphicon-comment"></span> Need help ? </li>
                        <li><span class="glyphicon glyphicon-comment"></span> Need help ? </li>
                        <li><span class="glyphicon glyphicon-comment"></span> Need help ? </li>
                        <li><span class="glyphicon glyphicon-comment"></span> Need help ? </li>
                    </ul>
                  </div>
                </div>
            </div>
            <div class="col-sm-3 col-xs-6">
                <div class="panel panel-success">
                  <div class="panel-heading">
                    <h3 class="panel-title">Report a bug</h3>
                  </div>
                  <div class="panel-body">
                    <ul>
                        <li> Found a bug ? </li>
                        <li> Report to us </li>
                        <li> and get money </li>
                        <li> Send email </li>
                        <li> support@gherus.com </li>
                    </ul>
                  </div>
                </div>
            </div>
</div>