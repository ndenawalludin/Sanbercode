<br>
<!-- baris ketiga -->
<div class="row"> 
    <div class="col-xs-6 col-sm-3">   
    <div  id="hover-cap-4col">
      <div class="thumbnail">
        <div class="caption">
            <h4>Ghebuk</h4>
            <p>Ghebuk is the most popular food from madura, it is a parotan kelapa dicampur tepung dan sebagainya</p>
            <p>Rp. 1.000 
            <button type="button" class="btn btn-warning btn-sm notif">Beli</button>
            <button type="button" class="btn  btn-success btn-sm">Detail</button>
            </p>
        </div>
        <img src="images/m/a.jpg" class='img-responsive'>
      </div>
    </div>
    </div>
    <div class="col-xs-6 col-sm-3">  
    <div  id="hover-cap-4col">
      <div class="thumbnail">
        <div class="caption">
            <h4>Rap-Orap</h4>
            <p>Rap-Orap is the most popular food from madura, it is a parotan kelapa</p>
            <p>Rp. 1.000 
            <button type="button" class="btn btn-warning btn-sm notif">Beli</button>
            <button type="button" class="btn btn-success btn-sm">Detail</button>
            </p>
        </div>
        <img src="images/m/a.jpg" class='img-responsive'>
      </div>
    </div>
    </div>
    <div class="col-xs-6 col-sm-3">  
    <div  id="hover-cap-4col">
      <div class="thumbnail">
        <div class="caption">
            <h4>Krepek Tette</h4>
            <p>Ghebuk is the most popular food from madura, it is a parotan kelapa</p>
            <p>Rp. 1.000 
            <button type="button" class="btn btn-warning btn-sm notif">Beli</button>
            <button type="button" class="btn btn-success btn-sm">Detail</button>
            </p>
            </div>
        <img src="images/m/a.jpg" class='img-responsive'>
      </div>
    </div>
    </div>
    <div class="col-xs-6 col-sm-3">  
    <div  id="hover-cap-4col">
      <div class="thumbnail">
        <div class="caption">
            <h4>Tapay</h4>
            <p>Ghebuk is the most popular food from madura, it is a parotan kelapa</p>
            <p>Rp. 1.000 
            <button type="button" class="btn btn-warning btn-sm notif">Beli</button>
            <button type="button" class="btn btn-success btn-sm">Detail</button>
            </p>
        </div>
        <img src="images/m/a.jpg" class='img-responsive'>
      </div>
    </div>
    </div>
</div>
<!-- baris ketiga -->
