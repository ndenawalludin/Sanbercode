
 <div class="menu-desktop">
						<ul class="main-menu">
							<li>
								<a href="/">Home</a>
								
							</li>

							<li>
								<a href="/shop">Shop</a>
							</li>

							<li>
								<a href="/blog">Blog</a>
							</li>

							<li>
								<a href="about.html">About</a>
							</li>

							<li>
								<a href="/contact">Contact</a>
							</li>

							
		
							<li>
							<a href="{{ route('login') }}" class="tulisan_kanan" title="Login / Register">
							<i class="fa fa-user"></i><span class="tulisan_kanan">Login / Register</span></a>
							</li>
		
							
						</ul>
    </div>	  