@extends ('layouts.app')

@section('content')
<div class="container">
    <form class="" action="{{route ('category.store')}}" method="post">
        {{csrf_field()}}
        <div class="form-group">
            <label for="">Baju</label>
            <input type="text" class="form-control" name="baju">
        </div>
        <div class="form-group">
            <label for="">Celana</label>
            <input type="text" class="form-control" name="celana">
        </div>
    
        <div class="form-group">
             <input type="submit" class="btn btn-primary" value="Save">
        </div>
    </form>
</div>
@endsection