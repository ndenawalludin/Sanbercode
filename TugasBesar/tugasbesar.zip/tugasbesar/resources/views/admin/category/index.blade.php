@extends ('layouts.app')

@section('content')
    <div class="panel panel-dafault">
        <div class="panel-heading">Category</div>
            @foreach ($categories as $category)
                <div class="panel-body">
                    <div class="pull-right">
                        <form action="{{route('category.destroy', $category)}}" method="post">
                            {{csrf_field()}}
                            {{method_field('DELETE')}}
                            <button type="submit" class="btn btn-xs btn-danger">Hapus</button>
                        </form>
                    </div>

                    <div class="form-group">
                        <div class="panel-heading">{{$category->baju}}</div>
                    </div>
                    <div class="form-group">
                        <div class="panel-heading">{{$category->celana}}</div>
                    </div>
                </div>
            @endforeach
    </div>
@endsection