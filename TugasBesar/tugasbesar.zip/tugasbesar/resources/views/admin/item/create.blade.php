@extends ('layouts.app')

@section('content')
<div class="container">
    <form class="" action="{{route ('category.store')}}" method="post">
        {{csrf_field()}}

        <div class="form-group">
            <label for="">Batik</label>
            <input type="text" class="form-control" name="batik">
        </div>
        <div class="form-group">
            <label for="">Kemeja</label>
            <input type="text" class="form-control" name="kemeja">
        </div>
        <div class="form-group">
            <label for="">Kaos</label>
            <input type="text" class="form-control" name="kaos">
        </div>
        <div class="form-group">
            <label for="">Kolor</label>
            <input type="text" class="form-control" name="kolor">
        </div>
        <div class="form-group">
            <label for="">Levis</label>
            <input type="text" class="form-control" name="levis">
        </div>
    
        <div class="form-group">
             <input type="submit" class="btn btn-primary" value="Save">
        </div>
    </form>
</div>
@endsection